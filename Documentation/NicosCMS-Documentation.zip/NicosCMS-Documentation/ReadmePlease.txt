Hi there
Thank you for downloading our software.

This software is free for all uses in return for your email

Please send us an email with the subject : NicosCMS Feedback
============================================================
Let us know what your experience was installing this software.
Please tell us about yourself and where you intend to use this software,
give us your comments and feedback, and any requests to be added to our wish list

We are shipping the AngryBNoffalo CMS (version of NicosCMS)
===========================================================
This is designed to be easier to use and easier to inslall
It comes with a built-in database H2, so that you dont have to make database installations 
to use this web application 

Disclaimer
==========
Please not this software is provided free, as is (voets toets) and no warrantee is provided 
or implied nor will we accept ant liability for loss of data, or profit or anticipated profit

Customization
=============
Please note this software comes with a built-in database H2 and is not scalable for Enterprise use
Should you require cuastomization , another database , that can be done for a small fee to cover our 
development costs

kind regards

Nico Michael
Chief Archnitect 

nico@nccsolutions.co.za
